import pandas as pd
import numpy as np
import json
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from extract import extract_data

def clean_hospitalisation(df):
    """
    Nettoie le DataFrame hospitalisation et retourne un DataFrame nettoyé
    """
    # Faire une copie pour éviter les modifications sur l'original
    df = df.copy()
    
    # --- 1. Normaliser les noms de colonnes ---
    df.columns = (
        df.columns.str.strip()
        .str.lower()
        .str.replace("-", "_", regex=False)
        .str.replace(" ", "_", regex=False)
    )

    # --- 2. Supprimer colonnes dupliquées ---
    df = df.loc[:, ~df.columns.duplicated()]

    # --- 3. Colonnes numériques ---
    numeric_cols = ["age", "cost", "length_of_stay", "satisfaction"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            df.loc[df[col] < 0, col] = np.nan

    # --- 4. Colonnes texte ---
    text_cols = ["gender", "condition", "procedure", "readmission", "outcome"]
    for col in text_cols:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .str.title()
                .replace("Nan", np.nan)
                .replace("None", np.nan)
            )

    # --- 5. Nettoyer patient_id ---
    if "patient_id" in df.columns:
        df["patient_id"] = (
            df["patient_id"]
            .astype(str)
            .str.strip()
            .str.upper()
            .replace("NAN", np.nan)
            .replace("NONE", np.nan)
        )

    # --- 6. Supprimer doublons et reset index ---
    df = df.drop_duplicates().reset_index(drop=True)

    # --- 7. Ajouter hospitalisation_id auto-incrémenté (clé primaire) ---
    df.insert(0, "hospitalisation_id", range(1, len(df) + 1))

    return df

def save_as_json(df, file_path):
    """
    Sauvegarde un DataFrame au format JSON avec une structure propre
    """
    # Convertir le DataFrame en liste de dictionnaires
    data_dict = df.to_dict(orient='records')
    
    # Sauvegarder en JSON avec formatage
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data_dict, f, indent=2, ensure_ascii=False, default=str)
    
    print(f"✅ Fichier JSON sauvegardé: {file_path}")

if __name__ == "__main__":
    try:
        # Extraction depuis extract_data.py
        data = extract_data()
        
        if data and "hospitalisation" in data:
            hospitalisation = data["hospitalisation"]
            
            # Convertir en DataFrame si ce n'est pas déjà le cas
            if isinstance(hospitalisation, list):
                hospitalisation_df = pd.DataFrame(hospitalisation)
            elif isinstance(hospitalisation, dict):
                hospitalisation_df = pd.DataFrame([hospitalisation])
            else:
                hospitalisation_df = hospitalisation
            
            print(f"📊 Données hospitalisation chargées: {hospitalisation_df.shape}")
            print(f"🔍 Colonnes originales: {list(hospitalisation_df.columns)}")
            
            # Nettoyage
            hospitalisation_cleaned = clean_hospitalisation(hospitalisation_df)
            
            # Créer le dossier de sauvegarde s'il n'existe pas
            output_dir = r"C:\Users\dadiw\Desktop\DadtaWarehouse project\sourcesNettoyes"
            os.makedirs(output_dir, exist_ok=True)
            
            # Sauvegarde en JSON
            json_output_path = os.path.join(output_dir, "hospitalisation_cleaned.json")
            save_as_json(hospitalisation_cleaned, json_output_path)
            
            # Afficher un aperçu
            print("\n📋 Aperçu des données nettoyées:")
            print(hospitalisation_cleaned.head())
            
            print(f"\n✅ Nettoyage terminé!")
            print(f"📁 Fichier sauvegardé: {json_output_path}")
            print(f"📊 Dimensions finales: {hospitalisation_cleaned.shape}")
            
        else:
            print("❌ Données hospitalisation non trouvées dans extract_data()")
            
    except Exception as e:
        print(f"❌ Erreur lors du nettoyage: {str(e)}")
        import traceback
        traceback.print_exc()
