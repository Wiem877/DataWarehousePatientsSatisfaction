import re
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) #__file__ calcule automatique du chemin de fichier courant
from extract import extract_data

def clean_patients_sql():
    """
    Nettoie le fichier patients.sql en conservant le format SQL
    """
    # Charger les données depuis extract_data
    data = extract_data()
    
    if not data or "patients_sql" not in data:
        print("❌ Données patients_sql non trouvées")
        return
    
    sql_content = data["patients_sql"]
    
    print("🎯 DÉBUT DU NETTOYAGE - PATIENTS.SQL")
    print("="*40)
    
    # --- NETTOYAGE DIRECT DU CONTENU SQL ---
    
    # 1. Convertir tous les patient_id en majuscules
    cleaned_sql = re.sub(
        r"VALUES \('([^']*)'", 
        lambda match: f"VALUES ('{match.group(1).upper()}'", 
        sql_content
    )
    print("✅ patient_id convertis en majuscules")
    
    # 2. Valider et corriger les âges (0-120)
    def validate_age(match):
        age = int(match.group(1))
        if age < 0:
            return "0"
        elif age > 120:
            return "120"
        return match.group(1)
    
    cleaned_sql = re.sub(r",(\d+),'(\d{4}-\d{2}-\d{2})'", 
                        lambda match: f",{validate_age(match)},'{match.group(2)}'", 
                        cleaned_sql)
    print("✅ Âges validés (0-120 ans)")
    
    # 3. Valider la satisfaction (0-100)
    def validate_satisfaction(match):
        satisfaction = int(match.group(1))
        if satisfaction < 0:
            return "0"
        elif satisfaction > 100:
            return "100"
        return match.group(1)
    
    cleaned_sql = re.sub(r",(\d+)\);", 
                        lambda match: f",{validate_satisfaction(match)});", 
                        cleaned_sql)
    print("✅ Satisfaction normalisée (0-100)")
    
    # 4. Standardiser les noms de services
    service_corrections = {
        'icu': 'ICU',
        'general_medicine': 'General_Medicine',
        'emergency': 'Emergency', 
        'surgery': 'Surgery'
    }
    
    for old, new in service_corrections.items():
        cleaned_sql = cleaned_sql.replace(f"'{old}'", f"'{new}'")
    print("✅ Services standardisés")
    
    # 5. Supprimer les doublons basés sur patient_id
    lines = cleaned_sql.split('\n')
    create_table_line = lines[0]
    insert_lines = lines[1:]
    
    unique_patients = {}
    for line in insert_lines:
        if line.startswith('INSERT'):
            match = re.search(r"VALUES \('([^']*)'", line)
            if match:
                patient_id = match.group(1)
                if patient_id not in unique_patients:
                    unique_patients[patient_id] = line
    
    final_sql = [create_table_line] + list(unique_patients.values())
    cleaned_sql = '\n'.join(final_sql)
    print("✅ Doublons supprimés")
    
    # 6. Valider le format des dates
    date_pattern = r"'(\d{4}-\d{2}-\d{2})'"
    def validate_date(match):
        date_str = match.group(1)
        try:
            # Vérifier si c'est une date valide
            from datetime import datetime
            datetime.strptime(date_str, '%Y-%m-%d')
            return match.group(0)
        except:
            return "'2023-01-01'"  # Date par défaut
    
    cleaned_sql = re.sub(date_pattern, validate_date, cleaned_sql)
    print("✅ Dates validées")
    
    # --- SAUVEGARDE ---
    output_dir = r"C:\Users\dadiw\Desktop\DadtaWarehouse project\sourcesNettoyes"
    os.makedirs(output_dir, exist_ok=True)
    
    output_path = os.path.join(output_dir, "patients_cleaned.sql")
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(cleaned_sql)
    
    print("="*40)
    print(f"✅ Fichier sauvegardé: {output_path}")
    print("🎉 NETTOYAGE TERMINÉ AVEC SUCCÈS!")

if __name__ == "__main__":
    clean_patients_sql()