import pandas as pd
import numpy as np
from datetime import datetime
import re
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from extract import extract_data
def clean_patient_data(df):
    """
    Nettoie le DataFrame patient avec les traitements spécifiques
    """
    # Faire une copie pour éviter les modifications sur l'original
    df = df.copy()
    
    print("🔍 Dimensions initiales:", df.shape)
    print("📋 Colonnes initiales:", list(df.columns))
    
    # --- 1. Normaliser les noms de colonnes ---
    df.columns = (
        df.columns.str.strip()
        .str.lower()
        .str.replace("-", "_", regex=False)
        .str.replace(" ", "_", regex=False)
    )
    print("✅ Colonnes normalisées")
    
    # --- 2. Nettoyer patient_id ---
    if "patient_id" in df.columns:
        df["patient_id"] = (
            df["patient_id"]
            .astype(str)
            .str.strip()
            .str.upper()
            .replace(["NAN", "NONE", "NULL", "N/A"], np.nan, regex=False)
        )
        print("✅ patient_id nettoyé")
    
    # --- 3. Corriger le genre ---
    if "gender" in df.columns:
        gender_mapping = {
            'feminin': 'F',
            'femme': 'F', 
            'female': 'F',
            'masculin': 'M',
            'homme': 'M',
            'male': 'M'
        }
        
        df["gender"] = (
            df["gender"]
            .astype(str)
            .str.strip()
            .str.upper()
            .str[0]  # Prendre seulement le premier caractère
            .replace(gender_mapping)
        )
        
        # Valider que seuls F et M sont présents
        valid_genders = ['F', 'M']
        df["gender"] = df["gender"].apply(lambda x: x if x in valid_genders else np.nan)
        print("✅ Genre corrigé et validé")
    
    # --- 4. Nettoyer les noms et prénoms ---
    name_columns = ["first_name", "last_name"]
    for col in name_columns:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .str.title()
                .replace(["Nan", "None", "Null", "N/A"], np.nan, regex=False)
            )
    print("✅ Noms et prénoms nettoyés")
    
    # --- 5. Nettoyer les dates ---
    date_columns = ["date_of_birth", "registration_date"]
    for col in date_columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce', format='%Y-%m-%d')
            # Supprimer les dates futures (non réalistes)
            if col == "date_of_birth":
                df[col] = df[col].where(df[col] < pd.Timestamp.now())
    print("✅ Dates nettoyées")
    
    # --- 6. Nettoyer le numéro de contact ---
    if "contact_number" in df.columns:
        df["contact_number"] = (
            df["contact_number"]
            .astype(str)
            .str.strip()
            .str.replace(r'\D', '', regex=True)  # Supprimer tous les caractères non numériques
            .replace('', np.nan)
        )
        
        # Valider la longueur du numéro (ajuster selon le pays)
        df["contact_number"] = df["contact_number"].apply(
            lambda x: x if pd.notna(x) and len(x) >= 8 and len(x) <= 15 else np.nan
        )
        print("✅ Numéros de contact nettoyés")
    
    # --- 7. Nettoyer l'adresse ---
    if "address" in df.columns:
        df["address"] = (
            df["address"]
            .astype(str)
            .str.strip()
            .str.replace(r'\s+', ' ', regex=True)  # Remplacer les espaces multiples par un seul
            .str.title()
            .replace(["Nan", "None", "Null", "N/A"], np.nan, regex=False)
        )
        print("✅ Adresses nettoyées")
    
    # --- 8. Nettoyer l'assurance ---
    if "insurance_provider" in df.columns:
        df["insurance_provider"] = (
            df["insurance_provider"]
            .astype(str)
            .str.strip()
            .str.title()
            .replace(["Nan", "None", "Null", "N/A"], np.nan, regex=False)
        )
    
    if "insurance_number" in df.columns:
        df["insurance_number"] = (
            df["insurance_number"]
            .astype(str)
            .str.strip()
            .str.upper()
            .replace(["NAN", "NONE", "NULL", "N/A"], np.nan, regex=False)
        )
        print("✅ Informations d'assurance nettoyées")
    
    # --- 9. Nettoyer les emails ---
    if "email" in df.columns:
        def validate_email(email):
            if pd.isna(email):
                return np.nan
            email = str(email).strip().lower()
            # Pattern simple de validation d'email
            pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            return email if re.match(pattern, email) else np.nan
        
        df["email"] = df["email"].apply(validate_email)
        print("✅ Emails validés")
    
    # --- 10. Calculer l'âge à partir de la date de naissance ---
    if "date_of_birth" in df.columns:
        today = pd.Timestamp.now()
        df["age"] = ((today - df["date_of_birth"]).dt.days / 365.25).astype(int)
        
        # Valider l'âge (entre 0 et 120 ans)
        df["age"] = df["age"].where((df["age"] >= 0) & (df["age"] <= 120))
        print("✅ Âge calculé et validé")
    
    # --- 11. Supprimer les doublons ---
    initial_count = len(df)
    df = df.drop_duplicates(subset=['patient_id'], keep='first')
    df = df.drop_duplicates()  # Doublons complets
    final_count = len(df)
    print(f"✅ Doublons supprimés: {initial_count - final_count} lignes")
    
    # --- 12. Réorganiser les colonnes ---
    preferred_order = [
        'patient_id', 'first_name', 'last_name', 'gender', 'date_of_birth', 'age',
        'contact_number', 'address', 'registration_date', 
        'insurance_provider', 'insurance_number', 'email'
    ]
    
    # Garder seulement les colonnes existantes dans l'ordre préféré
    existing_columns = [col for col in preferred_order if col in df.columns]
    other_columns = [col for col in df.columns if col not in existing_columns]
    df = df[existing_columns + other_columns]
    
    # --- 13. Réinitialiser l'index ---
    df = df.reset_index(drop=True)
    
    print(f"✅ Nettoyage terminé - Dimensions finales: {df.shape}")
    return df

def analyze_patient_data(df):
    """
    Analyse les données après nettoyage
    """
    print("\n" + "="*50)
    print("📊 ANALYSE APRÈS NETTOYAGE")
    print("="*50)
    
    print(f"Nombre total de patients: {len(df)}")
    print(f"Nombre de colonnes: {len(df.columns)}")
    
    print("\nValeurs manquantes par colonne:")
    missing_data = df.isnull().sum()
    for col, count in missing_data.items():
        if count > 0:
            percentage = (count / len(df)) * 100
            print(f"  - {col}: {count} ({percentage:.1f}%)")
    
    print("\nRépartition par genre:")
    if 'gender' in df.columns:
        print(df['gender'].value_counts(dropna=False))
    
    print("\nÂge statistique:")
    if 'age' in df.columns:
        print(f"  Moyenne: {df['age'].mean():.1f} ans")
        print(f"  Min: {df['age'].min()} ans, Max: {df['age'].max()} ans")

if __name__ == "__main__":
    try:
        # Charger les données depuis extract_data
        from extract import extract_data
        
        data = extract_data()
        
        if data and "patient" in data:
            patient_df = data["patient"]
            
            print("🎯 DÉBUT DU NETTOYAGE - PATIENT.CSV")
            print("="*50)
            
            # Nettoyage des données
            patient_cleaned = clean_patient_data(patient_df)
            
            # Analyse après nettoyage
            analyze_patient_data(patient_cleaned)
            
            # Sauvegarde
            output_path = r"C:\Users\dadiw\Desktop\DadtaWarehouse project\sourcesNettoyes\patient_cleaned.csv"
            patient_cleaned.to_csv(output_path, index=False, sep=';', encoding='utf-8')
            
            print(f"\n✅ Fichier sauvegardé: {output_path}")
            print("\n📋 Aperçu des données nettoyées:")
            print(patient_cleaned.head(10))
            
        else:
            print("❌ Données patient non trouvées dans extract_data()")
            
    except Exception as e:
        print(f"❌ Erreur lors du nettoyage: {str(e)}")
        import traceback
        traceback.print_exc()