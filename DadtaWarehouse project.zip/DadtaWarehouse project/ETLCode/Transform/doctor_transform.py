import pandas as pd
import numpy as np
import sys
import os

# Ajouter le dossier parent (ETLCode) au path 
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) #__file__ calcule automatique du chemin de fichier courant
from extract import extract_data


def clean_infopatient(df):
    # mettre en minuscules, enlever espaces, remplacer par _
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_", regex=False)
    #enlever les doublons
    df.drop_duplicates(subset=["doctor_id"], inplace=True)
    #Nettoyage du nom et prénom
    for col in ["first_name", "last_name"]:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str) #convertir en text
                .str.strip()#enlever les espaces avant/apres
                .str.title() #premiere lettre en maj
                .replace("nan", np.nan) 
            )

    # 4) Nettoyer la spécialité
    if "specialization" in df.columns:
        df["specialization"] = (
            df["specialization"]
            .astype(str)
            .str.strip()
            .str.title()          # "cardiologue" → "Cardiologue"
            .replace("nan", np.nan)
        )

    # 5) Normaliser le numéro de téléphone
    if "phone_number" in df.columns:
        df["phone_number"] = (
            df["phone_number"]
            .astype(str)
            .str.replace(r"[^0-9]", "", regex=True)  # garder seulement les chiffres
        )
        # Numéros vides → NaN
        df.loc[df["phone_number"].str.len() < 6, "phone_number"] = np.nan

    # 6) Convertir les années d'expérience en entier
    if "years_experience" in df.columns:
        df["years_experience"] = pd.to_numeric(df["years_experience"], errors="coerce")
        df.loc[df["years_experience"] < 0, "years_experience"] = np.nan

    # 7) Nettoyer hospital_branch
    if "hospital_branch" in df.columns:
        df["hospital_branch"] = (
            df["hospital_branch"]
                .astype(str)
                .str.strip()
                .str.title()
                .replace("nan", np.nan)
        )

    # 8) Nettoyer les emails
    if "email" in df.columns:
        df["email"] = df["email"].astype(str).str.strip().str.lower()
        df.loc[~df["email"].str.contains("@", na=False), "email"] = np.nan

    # 9) Remplacer les chaînes vides par NaN
    df.replace("", np.nan, inplace=True)

    return df

if __name__ == "__main__":
    data=extract_data()
    doctors =data["doctor"]
    doctors_cleaned=clean_infopatient(doctors)

    #enregistrer
    doctors_cleaned.to_excel(r"C:\Users\dadiw\Desktop\DadtaWarehouse project\sourcesNettoyes\doctors_cleaned.xlsx", index=False)
    print(doctors_cleaned.head())