import pandas as pd
import json
import os
import xml.etree.ElementTree as ET

def extract_data():
    # Définir le chemin de base
    base_path = r"C:\Users\dadiw\Desktop\DadtaWarehouse project\sourcesNettoyes"
    
    # Vérifier si le chemin existe
    if not os.path.exists(base_path):
        print(f"Erreur: Le chemin {base_path} n'existe pas")
        return None
    
    data = {}
    
    try:
        # 1. Charger doctors.xlsx
        doctors_path = os.path.join(base_path, "doctors.xlsx")
        if os.path.exists(doctors_path):
            data["doctor"] = pd.read_excel(doctors_path)
            print("✓ doctors.xlsx chargé")
        else:
            print("✗ doctors.xlsx non trouvé")

        # 2. Charger Hospitalisation.json
        hospitalisation_path = os.path.join(base_path, "Hospitalisation.json")
        if os.path.exists(hospitalisation_path):
            with open(hospitalisation_path, "r", encoding="utf-8") as f:
                data["hospitalisation"] = json.load(f)
            print("✓ Hospitalisation.json chargé")
        else:
            print("✗ Hospitalisation.json non trouvé")

        # 3. Charger patient.csv
        patient_path = os.path.join(base_path, "patient.csv")
        if os.path.exists(patient_path):
            # Essayer différents séparateurs
            try:
                data["patient"] = pd.read_csv(patient_path, sep=";")
            except:
                try:
                    data["patient"] = pd.read_csv(patient_path, sep=",")
                except:
                    data["patient"] = pd.read_csv(patient_path)
            print("✓ patient.csv chargé")
        else:
            print("✗ patient.csv non trouvé")

        # 4. Charger patients_cleaned.sql (lecture en tant que texte)
        patients_sql_path = os.path.join(base_path, "patients_cleaned.sql")
        if os.path.exists(patients_sql_path):
            with open(patients_sql_path, "r", encoding="utf-8") as f:
                data["patients_sql"] = f.read()
            print("✓ patients_cleaned.sql chargé")
        else:
            print("✗ patients_cleaned.sql non trouvé")

        # 5. Charger services_weekly.xml
        services_xml_path = os.path.join(base_path, "services_weekly.xml")
        if os.path.exists(services_xml_path):
            try:
                tree = ET.parse(services_xml_path)
                root = tree.getroot()
                
                # Convertir XML en liste de dictionnaires
                xml_data = []
                for row in root.findall('.//row'):
                    record = {}
                    for child in row:
                        record[child.tag] = child.text
                    xml_data.append(record)
                
                # Convertir en DataFrame
                if xml_data:
                    data["service_xml"] = pd.DataFrame(xml_data)
                else:
                    data["service_xml"] = pd.DataFrame()
                
                print("✓ services_weekly.xml chargé")
            except Exception as e:
                print(f"✗ Erreur lors du chargement de services_weekly.xml: {e}")
                data["service_xml"] = None
        else:
            print("✗ services_weekly.xml non trouvé")

        # Afficher le résumé des données chargées
        print("\n" + "="*50)
        print("RÉSUMÉ DES DONNÉES CHARGÉES:")
        print("="*50)
        
        for key, value in data.items():
            if key == "patients_sql":
                print(f"- {key}: {len(value)} caractères")
            elif key == "hospitalisation":
                if isinstance(value, list):
                    print(f"- {key}: {len(value)} éléments")
                elif isinstance(value, dict):
                    print(f"- {key}: {len(value)} clés")
            elif hasattr(value, 'shape'):  # DataFrame
                print(f"- {key}: {value.shape[0]} lignes × {value.shape[1]} colonnes")
            else:
                print(f"- {key}: {type(value)}")
        
        return data

    except Exception as e:
        print(f"Erreur lors du chargement des données: {str(e)}")
        return None

def list_available_files():
    """Lister tous les fichiers disponibles dans le dossier sourcesNettoyes"""
    base_path = r"C:\Users\dadiw\Desktop\DadtaWarehouse project\sourcesNettoyes"
    print("\nFichiers disponibles dans le dossier sourcesNettoyes:")
    print("="*50)
    
    if os.path.exists(base_path):
        for file in os.listdir(base_path):
            file_path = os.path.join(base_path, file)
            if os.path.isfile(file_path):
                size = os.path.getsize(file_path)
                print(f"- {file} ({size} octets)")
    else:
        print("Le dossier sourcesNettoyes n'existe pas")

# Lister les fichiers disponibles
list_available_files()

# Exécuter l'extraction
print("\n" + "="*50)
print("CHARGEMENT DES DONNÉES:")
print("="*50)
data = extract_data()

if data:
    print(f"\n✅ Extraction terminée avec succès!")
    print(f"📊 Nombre de datasets chargés: {len(data)}")
    print(f"🔑 Clés disponibles: {list(data.keys())}")
else:
    print("\n❌ Aucune donnée n'a pu être chargée")
